using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallContinue : MonoBehaviour
{
    public Sprite wallTopFullSprite;
    private Transform objectTransform;
    // Start is called before the first frame update
    void Start()
    {
        wallTopFullSprite = Resources.Load<Sprite>("StageImage/wallTop");
        objectTransform = transform;
        string[] splitName = gameObject.name.Split('m', '_');
        int y = int.Parse(splitName[1]) + 1;
        string compareName = splitName[0] + "m" + y.ToString() + "_" + splitName[2];
        foreach (var kvp in Main.gameObjectPosTable)
        {
            if (kvp.Key.name == compareName)
            {
                gameObject.GetComponent<SpriteRenderer>().sprite = wallTopFullSprite;
                break;

            }


        }
    }

    // Update is called once per frame
    void Update()
    {

    }
}

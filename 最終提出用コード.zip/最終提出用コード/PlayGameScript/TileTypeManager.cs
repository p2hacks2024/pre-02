using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileTypeManager : MonoBehaviour
{
    public Main.TileType type;
}

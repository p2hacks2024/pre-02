using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadSceneFade : MonoBehaviour
{
    [SerializeField] private Fade fade;
    [SerializeField] GameObject loadtext;
    [SerializeField] GameObject gameovertext;
    public float outFadeTime = 2.0f;
    public float inFadeTime = 2.0f;
    private bool isFadeOutComplete = false;
    private float time = 0f;
    public float waitTime = 3f;

    // Start is called before the first frame update
    void Start()
    {
        loadtext.SetActive(false);
        gameovertext.SetActive(false);
        // フェードアウトを開始
        fade.FadeOut(outFadeTime, () => isFadeOutComplete = true);
    }

    // Update is called once per frame
    void Update()
    {
        if (isFadeOutComplete)
        {
            // フェードアウト完了後の待機時間を加算
            time += Time.deltaTime;

            loadtext.SetActive(true);
            gameovertext.SetActive(false);
            if (SceneManage.beforeScene == "GameOver")
            {
                gameovertext.SetActive(true);
                loadtext.SetActive(false);
            }

            if (time > waitTime)
            {
                // フェードインを開始
                fade.FadeIn(inFadeTime, () =>
                {
                    Debug.Log(SceneManage.beforeScene);
                    Debug.Log(FloorCount.nowfloorcount);
                    if (SceneManage.beforeScene == "ShopScene")
                    {
                        SceneManager.LoadScene("PlayScene");//シーンを切り替える処理
                    }
                    else if (SceneManage.beforeScene == "PlayScene" && FloorCount.nowfloorcount < 5)
                    {
                        SceneManager.LoadScene("IventScene");//イベントシーンに切り替える処理
                        Debug.Log("イベントに移動");
                    }
                    else if (SceneManage.beforeScene == "StoryScene1" || SceneManage.beforeScene == "IventScene")
                    {
                        SceneManager.LoadScene("ShopScene");//ショップシーンに切り替える処理
                        Debug.Log("ショップに移動");
                    }
                    else if (SceneManage.beforeScene == "PlayScene" && FloorCount.nowfloorcount <= 5)
                    {
                        SceneManager.LoadScene("EndStoryScene");//エンドストーリシーンに切り替える処理
                        Debug.Log("エンドストーリに移動");
                    }
                    else if (SceneManage.beforeScene == "GameOver")
                    {
                        SceneManager.LoadScene("ShopScene");//エンドストーリシーンに切り替える処理
                        Debug.Log("ショップに移動");
                    }
                });

                // 待機処理を停止
                isFadeOutComplete = false;
            }
        }
    }
}

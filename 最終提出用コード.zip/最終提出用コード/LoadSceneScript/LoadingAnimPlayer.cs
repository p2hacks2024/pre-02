using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class LoadingAnimPlayer : MonoBehaviour
{
    public float duration = 1f;
    private Sequence[] sequences;

    void Start()
    {
        Image[] circles = GetComponentsInChildren<Image>(true); // 非アクティブ要素も取得
        sequences = new Sequence[circles.Length];

        for (int i = 0; i < circles.Length; i++)
        {
            RectTransform rectTransform = circles[i].rectTransform;

            if (rectTransform != null)
            {
                rectTransform.anchoredPosition = new Vector2((i - circles.Length / 2) * 50f, 0);

                Sequence sequence = DOTween.Sequence()
                    .SetLoops(-1, LoopType.Restart)
                    .SetDelay((duration / 2) * ((float)i / circles.Length))
                    .Append(rectTransform.DOAnchorPosY(30f, duration / 4))
                    .Append(rectTransform.DOAnchorPosY(0f, duration / 4))
                    .AppendInterval((duration / 2) * ((float)(1 - i) / circles.Length));

                sequences[i] = sequence;
                sequence.Play();
            }
            else
            {
                Debug.LogWarning("RectTransform is null, skipping animation for circle " + i);
            }
        }
    }

    void OnDestroy()
    {
        if (sequences != null)
        {
            foreach (var sequence in sequences)
            {
                sequence?.Kill(); // nullチェックして停止
            }
        }
    }
}

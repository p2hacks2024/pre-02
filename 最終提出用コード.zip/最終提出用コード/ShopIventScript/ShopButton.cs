using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ShopButton : MonoBehaviour
{
    [SerializeField] GameObject checkBrod;
    [SerializeField] Fade fade;
    public static bool checkBordFlag;
    //[SerializeField] GameObject fadeBord;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // if (checkBordFlag)
        // {
        //     checkBrod.SetActive(true);
        // }
        // if (!checkBordFlag)
        // {
        //     checkBrod.SetActive(false);
        // }
    }

    public void YesButton()
    {
        // checkBrod.SetActive(false);
        checkBordFlag = false;
        Debug.Log("Fade");
    }

    public void NoButton()
    {
        // checkBrod.SetActive(false);
        checkBordFlag = false;
    }
    public static void CheckBordOn()
    {
        checkBordFlag = true;
        Debug.Log("ON");
    }
    public static void CheckBordOff()
    {
        checkBordFlag = false;
        Debug.Log("OFF");
    }
    public void NextScene()
    {
        //ボタンを押したら1秒かけてフェードしてシーン移動
        //fade.FadeIn(秒数, () => やりたいこと);
        fade.FadeIn(1f, () => SceneManager.LoadScene("LoadScene"));//シーンを切り替える処理
        //SceneManager.LoadScene("");//シーンを切り替える処理
        Debug.Log("シーン移動");
        TextMove.buyFlag = false;
        TextMove.text = "いらっしゃい";
    }
}

using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems; // UIイベント用

public class LightStone : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public bool buttonFlag;
    bool runFlag = false;
    public float time;
    public bool lightStoneFlag0 = false;
    public bool lightStoneFlag1 = false;
    public bool lightStoneFlag2 = false;
    [SerializeField] GameObject itemExplain;//アイテムの説明
    // Start is called before the first frame update
    public AudioClip sound1;
    AudioSource audioSource;

    void Start()
    {
        //Componentを取得
        audioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if (runFlag && Gold.gold > 0)
        {
            audioSource.PlayOneShot(sound1);
            // ShopButton.CheckBordOff();
            if (lightStoneFlag0 && Gold.gold >= 2) { audioSource.PlayOneShot(sound1); Gold.gold -= 2; Destroy(gameObject); TextMove.buyFlag = true; Debug.Log("購入"); }
            if (lightStoneFlag1 && Gold.gold >= 5) { audioSource.PlayOneShot(sound1); Gold.gold -= 5; Destroy(gameObject); TextMove.buyFlag = true; Debug.Log("購入"); }
            if (lightStoneFlag2 && Gold.gold >= 10) { audioSource.PlayOneShot(sound1); Gold.gold -= 10; Destroy(gameObject); TextMove.buyFlag = true; Debug.Log("購入"); }
            runFlag = false;
        }
        else if (runFlag && Gold.gold <= 0)
        {
            Debug.Log("所持金が足りません");
            TextMove.nobuyFlag = true;
            runFlag = false;
        }
    }


    public void OnClikButton()
    {
        ShopButton.CheckBordOn();
    }

    // マウスがボタンに乗ったとき
    public void OnPointerEnter(PointerEventData eventData)
    {
        itemExplain.SetActive(true);
        Debug.Log("マウスがボタンに乗りました");
    }

    // マウスがボタンから外れたとき
    public void OnPointerExit(PointerEventData eventData)
    {
        itemExplain.SetActive(false);
        Debug.Log("マウスがボタンから離れました");
    }

    public void OnClike()
    {
        runFlag = true;
    }

    public void OnDestroy()
    {
        Destroy(gameObject);
    }
}

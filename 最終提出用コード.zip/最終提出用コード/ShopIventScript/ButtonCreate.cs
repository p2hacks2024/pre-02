using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonCreate : MonoBehaviour
{
    GameObject prefab;
    public GameObject itemButton;
    public GameObject itemButton1;
    public GameObject itemButton2;
    public GameObject itemButton3;
    public GameObject itemButton4;
    public GameObject itemButton5;
    public GameObject canvas;
    // リストを作成
    [SerializeField] List<GameObject> itemsCommonlist = new List<GameObject>();
    [SerializeField] List<GameObject> itemsRealist = new List<GameObject>();
    [SerializeField] List<GameObject> itemsEpiclist = new List<GameObject>();

    // Start is called before the first frame update
    void Start()
    {

        // int reaRnd = UnityEngine.Random.Range(0, itemsRealist.Count);//a~bの範囲で値が返る
        // int epicRnd = UnityEngine.Random.Range(0, itemsEpiclist.Count);//a~bの範囲で値が返る
    }

    private bool flag = true;
    // Update is called once per frame
    void Update()
    {


        while (flag)
        {
            GameObject obj = itemsCommonlist[CommonRnd()];
            prefab = (GameObject)Instantiate(obj, new Vector2(-170.0f, 280.0f), Quaternion.identity);//左上
            prefab.transform.SetParent(canvas.transform, false);

            obj = itemsCommonlist[CommonRnd()];
            prefab = (GameObject)Instantiate(obj, new Vector2(-170.0f, 0.0f), Quaternion.identity);//左中央
            prefab.transform.SetParent(canvas.transform, false);

            obj = itemsCommonlist[ReaRnd()];
            prefab = (GameObject)Instantiate(obj, new Vector2(-170.0f, -280.0f), Quaternion.identity);//左下
            prefab.transform.SetParent(canvas.transform, false);

            obj = itemsCommonlist[CommonRnd()];
            prefab = (GameObject)Instantiate(obj, new Vector2(170.0f, 280.0f), Quaternion.identity);//右上
            prefab.transform.SetParent(canvas.transform, false);

            obj = itemsCommonlist[CommonRnd()];
            prefab = (GameObject)Instantiate(obj, new Vector2(170.0f, 0.0f), Quaternion.identity);//右中央
            prefab.transform.SetParent(canvas.transform, false);

            obj = itemsEpiclist[EpicRnd()];
            prefab = (GameObject)Instantiate(obj, new Vector2(170.0f, -280.0f), Quaternion.identity);//右下
            prefab.transform.SetParent(canvas.transform, false);
            Debug.Log("生成完了");

            flag = false;
        }
    }

    private int CommonRnd()
    {
        int commonRnd = UnityEngine.Random.Range(0, itemsCommonlist.Count + 1);//a~bの範囲で値が返る
        return commonRnd;
    }

    private int ReaRnd()
    {
        int reaRnd = UnityEngine.Random.Range(0, itemsRealist.Count + 1);//a~bの範囲で値が返る
        return reaRnd;
    }
    private int EpicRnd()
    {
        int epicRnd = UnityEngine.Random.Range(0, itemsEpiclist.Count + 1);//a~bの範囲で値が返る
        return epicRnd;
    }
}

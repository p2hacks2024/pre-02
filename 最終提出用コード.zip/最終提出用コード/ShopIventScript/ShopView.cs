using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;//「UniTask」を使用するため。

public class ShopView : ViewBase
{
    public static bool buttonflag = false;
    // -------------------------------------------------------
    // ビューオープン時コール.
    // -------------------------------------------------------
    public override void OnViewOpened()
    {
        base.OnViewOpened();
    }

    // -------------------------------------------------------
    // ビュークローズ時コール.
    // -------------------------------------------------------
    public override void OnViewClosed()
    {
        base.OnViewClosed();
    }

    /// -------------------------------------------------------
    // 次の画面へ遷移
    // -------------------------------------------------------
    public async void NextScene()
    {
        Debug.Log("シーンが変わりました");
        await Scene.ChangeScene("StoryScene1");
    }
}

using UnityEngine;
using UnityEngine.EventSystems; // UIイベント用

public class Mouse : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
{
    // マウスがボタンに乗ったとき
    public void OnPointerEnter(PointerEventData eventData)
    {
        Debug.Log("マウスがボタンに乗りました");
    }

    // マウスがボタンから外れたとき
    public void OnPointerExit(PointerEventData eventData)
    {
        Debug.Log("マウスがボタンから離れました");
    }

    // ボタンをクリックしたとき
    public void OnPointerClick(PointerEventData eventData)
    {
        Debug.Log("ボタンがクリックされました");
    }
}

using System.Collections.Generic;
using UnityEngine;

public class ButtonCreate1 : MonoBehaviour
{
    public GameObject itemButton;
    public GameObject itemButton1;
    public GameObject itemButton2;
    public GameObject itemButton3;
    public GameObject itemButton4;
    public GameObject itemButton5;
    public GameObject canvas;

    [SerializeField] private List<GameObject> itemsCommonlist = new List<GameObject>();
    [SerializeField] private List<GameObject> itemsRealist = new List<GameObject>();
    [SerializeField] private List<GameObject> itemsEpiclist = new List<GameObject>();

    private bool flag = true;

    private void Start()
    {
        SceneManage.beforeScene = "ShopScene";
    }

    void Update()
    {
        if (flag)
        {
            CreateButtons();
            flag = false;
        }
    }

    private void CreateButtons()
    {
        Vector2[] positions = new Vector2[]
        {
            new Vector2(-170.0f, 280.0f),
            new Vector2(-170.0f, 0.0f),
            new Vector2(-170.0f, -280.0f),
            new Vector2(170.0f, 280.0f),
            new Vector2(170.0f, 0.0f),
            new Vector2(170.0f, -280.0f)
        };

        foreach (Vector2 position in positions)
        {
            GameObject obj = SelectRandomObject();
            if (obj != null)
            {
                GameObject prefab = Instantiate(obj, position, Quaternion.identity);
                prefab.transform.SetParent(canvas.transform, false);
                Debug.Log($"Created {obj.name} at {position}");
            }
        }
    }

    private GameObject SelectRandomObject()
    {
        List<GameObject> selectedList = itemsCommonlist; // Default to common list

        // Randomly pick which list to use
        int rnd = UnityEngine.Random.Range(0, 3);
        switch (rnd)
        {
            case 0:
                selectedList = itemsCommonlist;
                break;
            case 1:
                selectedList = itemsRealist;
                break;
            case 2:
                selectedList = itemsEpiclist;
                break;
        }

        int randomIndex = UnityEngine.Random.Range(0, selectedList.Count);
        return selectedList[randomIndex];
    }
}

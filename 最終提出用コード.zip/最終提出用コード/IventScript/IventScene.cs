using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class IventScene : SceneBase
{
    protected override void Start()
    {
        SceneManage.beforeScene = "IventScene";
        Debug.Log("開始");
        // シーンが読み込まれた後に実行される
        int viewcount = viewList.Count;
        initialViewIndex = Random.Range(0, viewcount); // 0 ~ viewList.Countまでの乱数

        foreach (var view in viewList)
        {
            if (viewList.IndexOf(view) == initialViewIndex)
            {
                Debug.Log(view);
                view.Scene = this;

                if (view.Transition != null && isInitialTransition == true)
                {
                    view.Transition.Canvas.alpha = 0;
                    view.gameObject.SetActive(true);
                    view.OnViewOpened();
                    view.Transition.TransitionIn();
                }
                else
                {
                    view.OnViewOpened();
                    view.gameObject.SetActive(true);
                }

                currentView = view;
            }
            else
            {
                view.gameObject.SetActive(false);
            }
        }
    }

    // シーンが再度実行された際にもリセットと初期化を行うための処理
    private void OnEnable()
    {
        // ビューリストのリセットなど必要な処理を実行する
        foreach (var view in viewList)
        {
            view.gameObject.SetActive(false);  // 全てのビューを非アクティブにする
        }

        Start();  // 初期処理を再度実行
    }
}

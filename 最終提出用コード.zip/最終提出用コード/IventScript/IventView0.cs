using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;//「UniTask」を使用するため。


public class IventView0 : ViewBase
{
    // トークウインドウ.
    [SerializeField] IvantTalkWindow IvantTalkWindow = null;
    // スプレッドシートリーダー.
    [SerializeField] SpreadSheetReader spreadSheetReader = null;
    [SerializeField] bool save_flag = false;
    int rnd;

    void Start()
    {
    }

    // -------------------------------------------------------
    // ビューオープン時コール.
    // -------------------------------------------------------
    public override async void OnViewOpened()
    {
        base.OnViewOpened();
        rnd = Random.Range(0, 3);//0~3までの乱数

        try
        {
            string _sheetId = "1KPZq4XB1bf2zTbpWQt_AWK1p6ghZWFBc1vRuQsq3-Io";
            string _Story001 = "「謎のシンボル」";
            string _Story002 = "「謎のシンボル」成功";
            string _Story003 = "「謎のシンボル」失敗";
            string _Story004 = "「謎のシンボル」その場を離れる";


            var data = await spreadSheetReader.LoadSpreadSheet(_sheetId, _Story001);
            await IvantTalkWindow.SetBg(data[0].Place, true);
            Debug.Log("会話開始");
            await IvantTalkWindow.Open();//会話実行
            var response = await IvantTalkWindow.IventTalkStart(data);
            await IvantTalkWindow.Close();//会話終了

            Debug.Log("次の展開は" + rnd);

            switch (rnd)
            {
                case 0:
                    {
                        var data2_1 = await spreadSheetReader.LoadSpreadSheet(_sheetId, _Story002);
                        await IvantTalkWindow.SetBg(data2_1[0].Place, true);
                        await IvantTalkWindow.Open();
                        await IvantTalkWindow.IventTalkStart(data2_1);
                        await IvantTalkWindow.Close();//会話終了

                    }
                    break;

                case 1:
                    {
                        var data2_2 = await spreadSheetReader.LoadSpreadSheet(_sheetId, _Story003);
                        await IvantTalkWindow.SetBg(data2_2[0].Place, true);
                        await IvantTalkWindow.Open();
                        await IvantTalkWindow.IventTalkStart(data2_2);
                        await IvantTalkWindow.Close();//会話終
                    }
                    break;
                case 2:
                    {
                        var data2_3 = await spreadSheetReader.LoadSpreadSheet(_sheetId, _Story004);
                        await IvantTalkWindow.SetBg(data2_3[0].Place, true);
                        await IvantTalkWindow.Open();
                        await IvantTalkWindow.IventTalkStart(data2_3);
                        await IvantTalkWindow.Close();//会話終
                    }
                    break;
            }
            await Scene.ChangeScene("LoadScene");
        }
        catch (System.OperationCanceledException e)
        {
            Debug.Log("テスト会話がキャンセルされました。" + e);
        }
    }

    // -------------------------------------------------------
    // ビュークローズ時コール.
    // -------------------------------------------------------
    public override void OnViewClosed()
    {
        base.OnViewClosed();
    }

    // -------------------------------------------------------
    // ホームに戻る.
    // -------------------------------------------------------
    public void OnBackToHomeButtonClicked()
    {
        Scene.ChangeScene("01_Home").Forget();
    }

    // ------------------------------------------------
    /// 2秒待って次のViewに移動.
    // ------------------------------------------------
    async UniTask ChangeViewWaitForSeconds(float waitTime = 2f)
    {
        try
        {
            await UniTask.Delay((int)(waitTime * 1000f), false, PlayerLoopTiming.Update, this.GetCancellationTokenOnDestroy());
            Scene.ChangeView(1).Forget();
            //(非同期処理).Forget() : 非同期処理を待機せずに実行.
        }
        catch (System.OperationCanceledException e)
        {
            Debug.Log("ChangeViewWaitForSecondsがキャンセルされました。" + e);
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpeningBGM : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        if (SceneManage.beforeScene == null) DontDestroyOnLoad(this);
    }

    // Update is called once per frame
    void Update()
    {
        if (SceneManage.beforeScene == "ShopScene")
        {
            Destroy(gameObject);
        }
    }
}

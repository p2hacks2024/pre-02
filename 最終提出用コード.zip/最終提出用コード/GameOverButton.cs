using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverButton : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void Retire()
    {
        SceneManager.LoadScene("OpeningScene");//シーンを切り替える処理
    }

    public void Continue()
    {
        SceneManage.beforeScene = "GameOver";
        SceneManager.LoadScene("LoadScene");//シーンを切り替える処理
    }
}

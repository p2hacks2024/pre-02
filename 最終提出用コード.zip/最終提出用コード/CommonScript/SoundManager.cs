using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class SoundManager : MonoBehaviour
{
    [SerializeField] private AudioSource bgmAudioSource;
    [SerializeField] private AudioSource seAudioSource;

    [SerializeField] private List<BGMSoundData> bgmSoundDatas;
    [SerializeField] private List<SESoundData> seSoundDatas;
    [SerializeField] private Slider BgmSlider;
    [SerializeField] private Slider SeSlider;
    [SerializeField] private Slider MasterSlider;
    [SerializeField] private Text bgmValue;
    [SerializeField] private Text seValue;
    [SerializeField] private Text masterValue;

    private static float masterVolume = 0.5f;
    private static float bgmMasterVolume = 0.5f;
    private static float seMasterVolume = 0.5f;

    public static SoundManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        InitializeSliders();
    }

    private void InitializeSliders()
    {
        BgmSlider.value = bgmMasterVolume;
        SeSlider.value = seMasterVolume;
        MasterSlider.value = masterVolume;

        UpdateVolumeText();
    }

    public void PlayBGM(BGMSoundData.BGM bgm)
    {
        BGMSoundData data = bgmSoundDatas.Find(d => d.bgm == bgm);
        bgmAudioSource.clip = data.audioClip;
        bgmAudioSource.volume = data.volume * bgmMasterVolume * masterVolume;
        bgmAudioSource.Play();
    }

    public void PlaySE(SESoundData.SE se)
    {
        SESoundData data = seSoundDatas.Find(d => d.se == se);
        seAudioSource.volume = data.volume * seMasterVolume * masterVolume;
        seAudioSource.PlayOneShot(data.audioClip);
    }

    public void OnChangeBgmSlider()
    {
        bgmMasterVolume = BgmSlider.value;
        UpdateVolumeText();
        UpdateBgmVolume();
    }

    public void OnChangeSeSlider()
    {
        seMasterVolume = SeSlider.value;
        UpdateVolumeText();
    }

    public void OnChangeMasterSlider()
    {
        masterVolume = MasterSlider.value;
        UpdateVolumeText();
        UpdateBgmVolume();
    }

    private void UpdateVolumeText()
    {
        bgmValue.text = Mathf.FloorToInt(BgmSlider.value * 100).ToString();
        seValue.text = Mathf.FloorToInt(SeSlider.value * 100).ToString();
        masterValue.text = Mathf.FloorToInt(MasterSlider.value * 100).ToString();
    }

    private void UpdateBgmVolume()
    {
        if (bgmAudioSource.isPlaying)
        {
            bgmAudioSource.volume = bgmMasterVolume * masterVolume;
        }
    }

    [System.Serializable]
    public class BGMSoundData
    {
        public enum BGM
        {
            Start,
            Doukutu,
            Ivent, // これがラベルになる
            Shop,
            End,
        }

        public BGM bgm;
        public AudioClip audioClip;
        [Range(0, 1)]
        public float volume = 1;
    }

    [System.Serializable]
    public class SESoundData
    {
        public enum SE
        {
            Kakutei,
            Cancel,
            Hoge, // これがラベルになる
        }

        public SE se;
        public AudioClip audioClip;
        [Range(0, 1)]
        public float volume = 1;

    }
}

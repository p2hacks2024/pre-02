using UnityEngine;

public class OpnenigScene : SceneBase
{
    protected override void Start()
    {
        base.Start();
    }
}

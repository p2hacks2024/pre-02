﻿class Program
{
    static void Main()
    {
        // Testクラスのインスタンスを作成
        Test test = new Test();

        // Run()メソッドを呼び出し
        test.Run();
    }
}

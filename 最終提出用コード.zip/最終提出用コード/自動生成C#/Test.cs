using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

class Test
{
    private const int grid = 5; // サイズを22x22に変更
    private const int iceGrid = 3; // サイズを22x22に変更
    private const int size = 11; // サイズを22x22に変更
    private static Random random = new Random();
    const int GridSize = 5; // グリッドのサイズ

    // 使用するポリオミノ（タイル）の種類
    static List<(string, (string Name, (int, int) Position)[])> Tiles = new List<(string, (string Name, (int, int) Position)[])>
    {
        ("1x1", new (string, (int, int))[] { ("10", (0, 0)) }),
        ("1x2", new (string, (int, int))[] { ("21", (0, 0)), ("", (0, 1)) }),
        ("2x1", new (string, (int, int))[] { ("22", (0, 0)), ("", (1, 0)) }),
        ("L型", new (string, (int, int))[] { ("31", (0, 0)), ("", (1, 0)), ("", (1, 1)) }),
        ("上下反転L型", new (string, (int, int))[] { ("32", (0, 0)), ("", (0, 1)), ("", (1, 0)) }),
        ("左右上下反転L型", new (string, (int, int))[] { ("33", (0, 0)), ("", (0, 1)), ("", (1, 1)) })
    };

    public void Run()
    {

        // ランダムなグリッドを作成（数字をランダムに配置）
        (int[,], string[,]) grid = GenerateRandomGrid(GridSize, GridSize);

        // 訪問履歴を保持するリストとセット
        List<(int, int, int, int)> path = new List<(int, int, int, int)>(); // int型のリスト
        HashSet<(int, int)> visited = new HashSet<(int, int)>(); // 訪問済みのセル

        // 開始地点
        int currentRow = 0, currentCol = 0;
        visited.Add((currentRow, currentCol)); // 開始地点を記録

        // 移動処理
        while (true)
        {
            // 次の移動先を決定
            var nextMove = GetNextMove(grid.Item1, currentRow, currentCol, visited);

            // 移動先がない場合、終了
            if (!nextMove.HasValue)
                break;

            // 移動を記録
            int nextRow = nextMove.Value.Item1;
            int nextCol = nextMove.Value.Item2;
            if (grid.Item1[currentRow, currentCol] != grid.Item1[nextRow, nextCol])
                path.Add((currentRow, currentCol, nextRow, nextCol)); // 現在地と移動先を記録

            // 現在地を更新
            currentRow = nextRow;
            currentCol = nextCol;

            // 移動先を訪問済みとして記録
            visited.Add((currentRow, currentCol));
        }
        int[,] maze = new int[55, 55];
        int[,] ans = new int[55, 55];

        foreach (var step in path)
        {
            Console.WriteLine(step.Item1 + "," + step.Item2 + "→" + step.Item3 + "," + step.Item4);
            if (step.Item1 == step.Item3 && step.Item2 + 1 == step.Item4)
            {
                maze[size * step.Item1 + size / 2, size * step.Item4 - 1] = 1;
                maze[size * step.Item1 + size / 2, size * step.Item4] = 1;
            }
            if (step.Item1 == step.Item3 && step.Item2 - 1 == step.Item4)
            {
                maze[size * step.Item1 + size / 2, size * step.Item2 - 1] = 1;
                maze[size * step.Item1 + size / 2, size * step.Item2] = 1;
            }
            if (step.Item1 + 1 == step.Item3 && step.Item2 == step.Item4)
            {
                maze[size * step.Item3 - 1, size * step.Item2 + size / 2] = 1;
                maze[size * step.Item3, size * step.Item2 + size / 2] = 1;
            }
            if (step.Item1 - 1 == step.Item3 && step.Item2 == step.Item4)
            {
                maze[size * step.Item1 - 1, size * step.Item2 + size / 2] = 1;
                maze[size * step.Item1, size * step.Item2 + size / 2] = 1;
            }
        }
        path.Add((currentRow, currentCol, currentRow - 1, currentCol));

        // 結果の出力
        PrintGrid(grid.Item1, grid.Item2, visited, maze, ans, path, currentRow, currentCol);
        Console.WriteLine("\n移動パス:");

        Console.WriteLine($"\n最後にいた位置: ({currentRow}, {currentCol})");

        PrintMaze(maze, ans);
                // ファイルに保存する
        SaveMazeToFile(maze, "maze.txt");

        Console.WriteLine("ファイルに保存しました。");
    }

    static void SaveMazeToFile(int[,] maze, string filePath)
    {
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            int rows = maze.GetLength(0);
            int cols = maze.GetLength(1);

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    writer.Write(maze[i, j]);
                    if (j < cols - 1)
                    {
                        writer.Write(","); // カンマで区切る
                    }
                }
                writer.WriteLine(); // 行ごとに改行
            }
        }
    }
    
    // ランダムなグリッドを生成
    static (int[,], string[,]) GenerateRandomGrid(int rows, int cols)
    {
        // 5x5の空のグリッドを作成
        int[,] grid = new int[GridSize, GridSize];
        string[,] tileGrid = new string[GridSize, GridSize];

        // タイルをランダムに配置
        Random rand = new Random();
        int tileId = 1; // タイルの識別番号

        for (int i = 0; i < 10000; i++) // 最大1000回試みる
        {
            // ランダムなタイルを選択
            var tile = Tiles[rand.Next(Tiles.Count)];

            // ランダムな位置を選択
            int startRow = rand.Next(GridSize);
            int startCol = rand.Next(GridSize);

            // タイルが収まるかチェック
            bool fits = true;
            foreach (var (name, position) in tile.Item2)
            {
                int r = startRow + position.Item1;
                int c = startCol + position.Item2;
                if (r < 0 || r >= GridSize || c < 0 || c >= GridSize || grid[r, c] != 0)
                {
                    fits = false;
                    break;
                }
            }

            // 収まる場合、タイルを配置
            if (fits)
            {
                foreach (var (name, position) in tile.Item2)
                {
                    grid[startRow + position.Item1, startCol + position.Item2] = i;
                    tileGrid[startRow + position.Item1, startCol + position.Item2] = name;
                }
                tileId++; // 次のタイル番号
            }
        }
        return (grid, tileGrid);
    }

    // 次の移動先を決定
    static (int, int)? GetNextMove(int[,] grid, int row, int col, HashSet<(int, int)> visited)
    {
        int currentValue = grid[row, col];
        int rows = grid.GetLength(0);
        int cols = grid.GetLength(1);

        // 斜めも含む8方向を定義
        int[][] allDirections = new int[][]
        {
        new int[] { -1, 0 },  // 上
        new int[] { 1, 0 },   // 下
        new int[] { 0, -1 },  // 左
        new int[] { 0, 1 },   // 右
        new int[] { -1, -1 }, // 左上
        new int[] { -1, 1 },  // 右上
        new int[] { 1, -1 },  // 左下
        new int[] { 1, 1 }    // 右下
        };

        // 隣接の4方向（上下左右）のみ
        int[][] adjacentDirections = new int[][]
        {
        new int[] { -1, 0 }, // 上
        new int[] { 1, 0 },  // 下
        new int[] { 0, -1 }, // 左
        new int[] { 0, 1 }   // 右
        };

        // 同じ数字のセルを探索（斜めを含む8マス）
        foreach (var dir in allDirections)
        {
            int newRow = row + dir[0];
            int newCol = col + dir[1];
            if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols && !visited.Contains((newRow, newCol)))
            {
                if (grid[newRow, newCol] == currentValue && currentValue != 0)
                    return (newRow, newCol);
            }
        }

        // 異なる数字のセルを探索（隣接4マスのみ）
        (int, int)? smallestNeighbor = null;
        int smallestValue = int.MaxValue;
        foreach (var dir in adjacentDirections)
        {
            int newRow = row + dir[0];
            int newCol = col + dir[1];
            if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols && !visited.Contains((newRow, newCol)))
            {
                if (grid[newRow, newCol] < smallestValue)
                {
                    smallestNeighbor = (newRow, newCol);
                    smallestValue = grid[newRow, newCol];
                }
            }
        }

        return smallestNeighbor;
    }

    // グリッドを出力
    static void PrintGrid(int[,] grid, string[,] tileGrid, HashSet<(int, int)> nextMove, int[,] maze, int[,] ans, List<(int, int, int, int)> path, int currentRow, int currentCol)
    {
        bool first = true;
        Console.WriteLine("グリッド:");
        for (int r = 0; r < grid.GetLength(0); r++)
        {
            for (int c = 0; c < grid.GetLength(1); c++)
            {
                int startX = size * r + size / 2;
                int startY = size * c + size / 2 - 1;
                int goalX = size * r + size / 2;
                int goalY = size * c + size / 2 + 1;
                // nextMoveに現在の座標(r, c)が含まれている場合に出力
                if (nextMove.Contains((r, c)))
                {
                    Console.Write($"{grid[r, c]}({tileGrid[r, c]})\t");
                }
                else
                {
                    Console.Write("0" + "\t");  // 出力しない場合は空白を表示
                }
                int[,] coordinates = { };
                if (tileGrid[r, c] == "33")
                {
                    coordinates = new int[,]
                    {
                        { 0, 0 },
                        { 0, 1 },
                        { 1, 1 }
                    };
                }
                if (tileGrid[r, c] == "32")
                {
                    coordinates = new int[,]
                    {
                        { 0, 0 },
                        { 0, 1 },
                        { 1, 0 }
                    };
                }
                if (tileGrid[r, c] == "31")
                {
                    coordinates = new int[,]
                    {
                        { 0, 0 },
                        { 1, 0 },
                        { 1, 1 }
                    };
                }
                if (tileGrid[r, c] == "21")
                {
                    coordinates = new int[,]
                    {
                        { 0, 0 },
                        { 0, 1 }
                    };
                }
                if (tileGrid[r, c] == "22")
                {
                    coordinates = new int[,]
                    {
                        { 0, 0 },
                        { 1, 0 }
                    };
                }
                if (tileGrid[r, c] == "10")
                {
                    coordinates = new int[,]
                    {
                        { 0, 0 }
                    };
                }
                // リストの内容を順番に取得して表示
                for (int i = 0; i < coordinates.GetLength(0); i++)
                {
                    foreach (var step in path)
                    {
                        if (step.Item1 == step.Item3 && step.Item2 + 1 == step.Item4)
                        {
                            if (r + coordinates[i, 0] == step.Item1 && c + coordinates[i, 1] == step.Item2)
                            {
                                startX = size * (r + coordinates[i, 0]) + size / 2;
                                startY = size * (c + coordinates[i, 1] + 1) - 2;
                            }
                            if (r + coordinates[i, 0] == step.Item3 && c + coordinates[i, 1] == step.Item4)
                            {
                                goalX = size * (r + coordinates[i, 0]) + size / 2;
                                goalY = size * (c + coordinates[i, 1]) + 1;
                            }
                        }
                        if (step.Item1 == step.Item3 && step.Item2 - 1 == step.Item4)
                        {
                            if (r + coordinates[i, 0] == step.Item1 && c + coordinates[i, 1] == step.Item2)
                            {
                                startX = size * (r + coordinates[i, 0]) + size / 2;
                                startY = size * (c + coordinates[i, 1]) + 1;
                            }
                            if (r + coordinates[i, 0] == step.Item3 && c + coordinates[i, 1] == step.Item4)
                            {
                                goalX = size * (r + coordinates[i, 0]) + size / 2;
                                goalY = size * (c + coordinates[i, 1] + 1) - 2;
                            }
                        }
                        if (step.Item1 + 1 == step.Item3 && step.Item2 == step.Item4)
                        {
                            if (r + coordinates[i, 0] == step.Item1 && c + coordinates[i, 1] == step.Item2)
                            {
                                startX = size * (r + coordinates[i, 0] + 1) - 2;
                                startY = size * (c + coordinates[i, 1]) + size / 2;
                            }
                            if (r + coordinates[i, 0] == step.Item3 && c + coordinates[i, 1] == step.Item4)
                            {
                                goalX = size * (r + coordinates[i, 0]) + 1;
                                goalY = size * (c + coordinates[i, 1]) + size / 2;
                            }
                        }
                        if (step.Item1 - 1 == step.Item3 && step.Item2 == step.Item4)
                        {
                            if (r + coordinates[i, 0] == step.Item1 && c + coordinates[i, 1] == step.Item2)
                            {
                                startX = size * (r + coordinates[i, 0]) + 1;
                                startY = size * (c + coordinates[i, 1]) + size / 2;
                            }
                            if (r + coordinates[i, 0] == step.Item3 && c + coordinates[i, 1] == step.Item4)
                            {
                                goalX = size * (r + coordinates[i, 0] + 1) - 2;
                                goalY = size * (c + coordinates[i, 1]) + size / 2;
                            }
                        }
                    }
                }
                int selectPuzzle = random.Next(0, 2);
                if (first)
                {
                    first = false;
                    goalX = 1;
                    goalY = 1;
                }

                if (coordinates.GetLength(0) == 3)
                {
                    if (tileGrid[r, c] == "33")
                    {
                        if (selectPuzzle == 0) GenerateIceMaze(c, r, "33", startY, startX, goalY, goalX, maze, ans);
                        if (selectPuzzle == 1)
                        {
                            for (int i = c * size; i < (c + 2) * size; i++)
                            {
                                for (int j = r * size; j < (r + 2) * size; j++)
                                {
                                    maze[j, i] = 1;
                                }
                            }
                            for (int i = (c) * size; i < (c + 1) * size; i++)
                            {
                                for (int j = (r + 1) * size; j < (r + 2) * size; j++)
                                {
                                    maze[j, i] = 0;
                                }
                            }
                            GenerateMaze(c, r, "31", startY, startX, goalY, goalX, maze, c * size + 1, r * size + 1);
                            GenerateMaze(c + 1, r, "31", startY, startX, goalY, goalX, maze, (c + 1) * size + 1, r * size + 1);
                            GenerateMaze(c, r + 1, "31", startY, startX, goalY, goalX, maze, c * size + 1, (r + 1) * size + 1);
                            GenerateMaze(c + 1, r + 1, "31", startY, startX, goalY, goalX, maze, (c + 1) * size + 1, (r + 1) * size + 1);
                            maze[r * size + size / 2, (c + 1) * size - 1] = 0;
                            maze[r * size + size / 2, (c + 1) * size] = 0;
                            maze[(r + 1) * size, (c + 1) * size + size / 2] = 0;
                            maze[(r + 1) * size - 1, (c + 1) * size + size / 2] = 0;
                        }
                    }
                    if (tileGrid[r, c] == "32")
                    {
                        if (selectPuzzle == 0) GenerateIceMaze(c, r, "32", startY, startX, goalY, goalX, maze, ans);
                        if (selectPuzzle == 1)
                        {
                            for (int i = c * size; i < (c + 2) * size; i++)
                            {
                                for (int j = r * size; j < (r + 2) * size; j++)
                                {
                                    maze[j, i] = 1;
                                }
                            }
                            for (int i = (c + 1) * size; i < (c + 2) * size; i++)
                            {
                                for (int j = (r + 1) * size; j < (r + 2) * size; j++)
                                {
                                    maze[j, i] = 0;
                                }
                            }
                            GenerateMaze(c, r, "31", startY, startX, goalY, goalX, maze, c * size + 1, r * size + 1);
                            GenerateMaze(c + 1, r, "31", startY, startX, goalY, goalX, maze, (c + 1) * size + 1, r * size + 1);
                            GenerateMaze(c, r + 1, "31", startY, startX, goalY, goalX, maze, c * size + 1, (r + 1) * size + 1);
                            GenerateMaze(c + 1, r + 1, "31", startY, startX, goalY, goalX, maze, (c + 1) * size + 1, (r + 1) * size + 1);
                            maze[r * size + size / 2, (c + 1) * size - 1] = 0;
                            maze[r * size + size / 2, (c + 1) * size] = 0;
                            maze[(r + 1) * size, c * size + size / 2] = 0;
                            maze[(r + 1) * size - 1, c * size + size / 2] = 0;
                        }
                    }
                    if (tileGrid[r, c] == "31")
                    {
                        if (selectPuzzle == 0) GenerateIceMaze(c, r, "31", startY, startX, goalY, goalX, maze, ans);
                        if (selectPuzzle == 1)
                        {
                            for (int i = c * size; i < (c + 2) * size; i++)
                            {
                                for (int j = r * size; j < (r + 2) * size; j++)
                                {
                                    maze[j, i] = 1;
                                }
                            }
                            for (int i = (c + 1) * size; i < (c + 2) * size; i++)
                            {
                                for (int j = (r) * size; j < (r + 1) * size; j++)
                                {
                                    maze[j, i] = 0;
                                }
                            }
                            GenerateMaze(c, r, "31", startY, startX, goalY, goalX, maze, c * size + 1, r * size + 1);
                            GenerateMaze(c + 1, r, "31", startY, startX, goalY, goalX, maze, (c + 1) * size + 1, r * size + 1);
                            GenerateMaze(c, r + 1, "31", startY, startX, goalY, goalX, maze, c * size + 1, (r + 1) * size + 1);
                            GenerateMaze(c + 1, r + 1, "31", startY, startX, goalY, goalX, maze, (c + 1) * size + 1, (r + 1) * size + 1);
                            maze[(r + 1) * size + size / 2, (c + 1) * size - 1] = 0;
                            maze[(r + 1) * size + size / 2, (c + 1) * size] = 0;
                            maze[(r + 1) * size, c * size + size / 2] = 0;
                            maze[(r + 1) * size - 1, c * size + size / 2] = 0;
                        }
                    }
                }
                if (coordinates.GetLength(0) == 2)
                {
                    if (tileGrid[r, c] == "21")
                    {
                        if (selectPuzzle == 0) GenerateIceMaze(c, r, "21", startY, startX, goalY, goalX, maze, ans);
                        if (selectPuzzle == 1)
                        {
                            for (int i = c * size; i < (c + 2) * size; i++)
                            {
                                for (int j = r * size; j < (r + 1) * size; j++)
                                {
                                    maze[j, i] = 1;
                                }
                            }
                            GenerateMaze(c, r, "21", startY, startX, goalY, goalX, maze, c * size + 1, r * size + 1);
                            GenerateMaze(c + 1, r, "21", startY, startX, goalY, goalX, maze, (c + 1) * size + 1, r * size + 1);
                            maze[(r) * size + size / 2, (c + 1) * size] = 0;
                            maze[(r) * size + size / 2, (c + 1) * size - 1] = 0;
                        }
                    }
                    if (tileGrid[r, c] == "22")
                    {
                        if (selectPuzzle == 0) GenerateIceMaze(c, r, "22", startY, startX, goalY, goalX, maze, ans);
                        if (selectPuzzle == 1)
                        {
                            for (int i = c * size; i < (c + 1) * size; i++)
                            {
                                for (int j = r * size; j < (r + 2) * size; j++)
                                {
                                    maze[j, i] = 1;
                                }
                            }
                            GenerateMaze(c, r, "22", startY, startX, goalY, goalX, maze, c * size + 1, r * size + 1);
                            GenerateMaze(c, r + 1, "22", startY, startX, goalY, goalX, maze, c * size + 1, (r + 1) * size + 1);
                            maze[(r + 1) * size - 1, c * size + size / 2] = 0;
                            maze[(r + 1) * size, c * size + size / 2] = 0;

                        }
                    }
                }
                if (coordinates.GetLength(0) == 1)
                {
                    if (tileGrid[r, c] == "10")
                    {
                        if (selectPuzzle == 0) GenerateIceMaze(c, r, "10", startY, startX, goalY, goalX, maze, ans);
                        if (selectPuzzle == 1)
                        {
                            for (int i = c * size; i < (c + 1) * size; i++)
                            {
                                for (int j = r * size; j < (r + 1) * size; j++)
                                {
                                    maze[j, i] = 1;
                                }
                            }
                            GenerateMaze(c, r, "10", startY, startX, goalY, goalX, maze, c * size + 1, r * size + 1);
                        }
                    }
                }

                foreach (var step in path)
                {

                    if (step.Item1 == currentRow && step.Item2 == currentCol)
                    {
                        maze[step.Item1 * size, step.Item2 * size + size / 2] = 0;
                    }
                    else
                    {
                        if (step.Item1 == step.Item3 && step.Item2 + 1 == step.Item4)
                        {
                            maze[step.Item1 * size + size / 2, (step.Item2 + 1) * size] = 0;
                            maze[step.Item1 * size + size / 2, (step.Item2 + 1) * size - 1] = 0;
                        }
                        if (step.Item1 == step.Item3 && step.Item2 - 1 == step.Item4)
                        {
                            maze[step.Item1 * size + size / 2, step.Item2 * size] = 0;
                            maze[step.Item1 * size + size / 2, step.Item2 * size - 1] = 0;
                        }
                        if (step.Item1 + 1 == step.Item3 && step.Item2 == step.Item4)
                        {
                            maze[(step.Item1 + 1) * size, step.Item2 * size + size / 2] = 0;
                            maze[(step.Item1 + 1) * size - 1, step.Item2 * size + size / 2] = 0;
                        }
                        if (step.Item1 - 1 == step.Item3 && step.Item2 == step.Item4)
                        {
                            maze[(step.Item1) * size, step.Item2 * size + size / 2] = 0;
                            maze[(step.Item1) * size - 1, step.Item2 * size + size / 2] = 0;
                        }
                    }
                    maze[currentRow * size, currentCol * size] = 4;
                }

            }
            Console.WriteLine();
        }
    }
    private static void GenerateIceMaze(int x, int y, string str, int startX, int startY, int goalX, int goalY, int[,] maze, int[,] ans)
    {
        while (true)
        {
            int remX = 1;
            int remY = 1;
            if (str == "33") { remX = 2; remY = 2; }
            if (str == "32") { remX = 2; remY = 2; }
            if (str == "31") { remX = 2; remY = 2; }
            if (str == "21") { remX = 2; remY = 1; }
            if (str == "22") { remX = 1; remY = 2; }
            if (str == "10") { remX = 1; remY = 1; }
            // 配列をリセット
            for (int k = size * y; k < size * (y + remY); k++)
            {
                for (int l = size * x; l < size * (x + remX); l++)
                {
                    maze[k, l] = 8;
                    ans[k, l] = 0;
                }
            }
            if (str == "33") iceCreateLShape(x + 0, y + 1, maze, ans);
            if (str == "32") iceCreateLShape(x + 1, y + 1, maze, ans);
            if (str == "31") iceCreateLShape(x + 1, y + 0, maze, ans);
            int j = startX;
            int i = startY;
            ans[i, j] = 1;

            for (int sss = 0; sss < size * 2; sss++)
            {
                int rand = random.Next(0, 4);
                int steps = random.Next(2, 3);

                for (int kkk = 0; kkk < steps; kkk++)
                {
                    if (rand == 0 && i < size * (y + remY) - 2 && maze[i - 1, j] != 1) // 上方向
                    {
                        if (kkk == 0 && ans[i - 1, j] == 0) maze[i - 1, j] = 1;
                        if (ans[i + 1, j] == 0 && maze[i + 1, j] != 1) i++;
                    }
                    else if (rand == 1 && j < size * (x + remX) - 2 && maze[i, j - 1] != 1) // 左方向
                    {
                        if (kkk == 0 && ans[i, j - 1] == 0) maze[i, j - 1] = 1;
                        if (ans[i, j + 1] == 0 && maze[i, j + 1] != 1) j++;
                    }
                    else if (rand == 2 && i > size * y + 1 && maze[i + 1, j] != 1) // 下方向
                    {
                        if (kkk == 0 && ans[i + 1, j] == 0) maze[i + 1, j] = 1;
                        if (ans[i - 1, j] == 0 && maze[i - 1, j] != 1) i--;
                    }
                    else if (rand == 3 && j > size * x + 1 && maze[i, j + 1] != 1) // 右方向
                    {
                        if (kkk == 0 && ans[i, j + 1] == 0) maze[i, j + 1] = 1;
                        if (ans[i, j - 1] == 0 && maze[i, j - 1] != 1) j--;
                    }

                    ans[i, j] = 1;
                }
            }
            if (j == goalX && i == goalY)
            {
                maze[goalX, goalY] = 0;
                break;
            }
        }
    }

    private static void iceCreateLShape(int iceGridX, int iceGridY, int[,] maze, int[,] ans)
    {
        {
            // 左下のL字型領域を空白にする
            for (int y = iceGridY * 11; y < (iceGridY + 1) * 11; y++) // 下半分をループ
            {
                for (int x = iceGridX * 11; x < (iceGridX + 1) * 11; x++) // 左半分をループ
                {
                    maze[y, x] = 1; // 壁として固定
                    ans[y, x] = 0;  // 解答ルートも削除
                }
            }
        }
    }

    private static void PrintMaze(int[,] maze, int[,] ans)
    {
        for (int y = 0; y < 55; y++)
        {
            for (int x = 0; x < 55; x++)
            {
                if (maze[y, x] == 1) Console.Write("■ ");
                else if (ans[y, x] == 1) Console.Write("□ ");
                else if (maze[y, x] == 8) Console.Write("_ ");
                else if (maze[y, x] == 0) Console.Write("  ");
                else Console.Write("N ");
            }
            Console.WriteLine();
        }
    }
    private static void GenerateMaze(int x2, int y2, string str, int startX, int startY, int goalX, int goalY, int[,] maze, int x, int y)
    {
        maze[y, x] = 0; // 現在地を通路にする

        // シャッフルした方向リストを作成
        int[][] directions = new int[][]
        {
            new int[] { 0, -2 }, // 上
            new int[] { 2, 0 },  // 右
            new int[] { 0, 2 },  // 下
            new int[] { -2, 0 }  // 左
        };
        Shuffle(directions);

        foreach (var dir in directions)
        {
            int nx = x + dir[0];
            int ny = y + dir[1];

            // 2マス先が迷路の範囲内かつ未訪問なら
            if (IsInBounds(x2, y2, nx, ny, str) && maze[ny, nx] == 1)
            {
                // 壁を壊して通路にする
                maze[y + dir[1] / 2, x + dir[0] / 2] = 0;
                // 再帰的に次のマスを処理
                GenerateMaze(x2, y2, str, startY, startX, goalY, goalX, maze, nx, ny);
            }
        }
    }

    private static bool IsInBounds(int x2, int y2, int x, int y, string str)
    {
        return x > x2 * size && x < (x2 + 1) * size - 1 && y > y2 * size && y < (y2 + 1) * size - 1;
    }

    private static void Shuffle(int[][] array)
    {
        for (int i = array.Length - 1; i > 0; i--)
        {
            int j = random.Next(i + 1);
            var temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }
}

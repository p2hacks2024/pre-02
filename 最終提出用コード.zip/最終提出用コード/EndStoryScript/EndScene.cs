using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndScene : SceneBase
{
    protected override void Start()
    {
        // ビューのリスト全てに.
        //varは型推論と呼ばれ自動的に型を設定してくれます。
        foreach (var view in viewList)
        {
            // シーンを設定.
            view.Scene = this;
            // 初期インデックスのビューに対しての処理.
            if (viewList.IndexOf(view) == initialViewIndex)
            {
                // トランジションする場合.
                if (view.Transition != null && isInitialTransition == true)
                {
                    view.Transition.Canvas.alpha = 0;
                    view.gameObject.SetActive(true);
                    view.OnViewOpened();
                    view.Transition.TransitionIn();
                }
                // トランジションしない場合.
                else
                {
                    view.OnViewOpened();
                    view.gameObject.SetActive(true);
                }
                // 現在のビューを設定.
                currentView = view;
            }
            // 初期ビュー以外に対しての処理.
            else
            {
                view.gameObject.SetActive(false);
            }
        }
    }
}

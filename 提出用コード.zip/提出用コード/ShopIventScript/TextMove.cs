using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TextMove : MonoBehaviour
{
    [SerializeField] public TextMeshProUGUI talk;
    public static bool buyFlag = false;
    public static bool nobuyFlag = false;
    public static string text;
    // Start is called before the first frame update
    void Start()
    {
        text = talk.text;
    }

    // Update is called once per frame
    void Update()
    {
        if (buyFlag)
        {
            talk.text = "ありがとよ";
        }
        if (nobuyFlag)
        {
            talk.text = "ただではあげれないね～";
        }
    }
}

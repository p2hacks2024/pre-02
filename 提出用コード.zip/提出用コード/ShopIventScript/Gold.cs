using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Gold : MonoBehaviour
{
    [SerializeField] public TextMeshProUGUI goldtext;
    // Start is called before the first frame update
    public static int gold = 100;
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        goldtext.text = gold.ToString();
        if (gold < 0)
        {
            gold = 0;
        }
    }
}

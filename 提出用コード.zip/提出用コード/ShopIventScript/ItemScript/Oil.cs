using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems; // UIイベント用

public class Oil : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public bool buttonFlag;
    bool runFlag = false;
    public float time;
    public bool oilStoneFlag0 = false;
    public bool oilStoneFlag1 = false;
    public bool oilStoneFlag2 = false;
    [SerializeField] GameObject itemExplain;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (runFlag && Gold.gold > 0)
        {
            //シーンの移動
            Debug.Log("シーン移動");
            runFlag = false;
            ShopButton.CheckBordOff();
            if (oilStoneFlag0) ;
            if (oilStoneFlag1) ;
            if (oilStoneFlag2) ;
        }
    }

    public void OnClikButton()
    {
        ShopButton.CheckBordOn();
    }

    // マウスがボタンに乗ったとき
    public void OnPointerEnter(PointerEventData eventData)
    {
        itemExplain.SetActive(true);
        Debug.Log("マウスがボタンに乗りました");
    }

    // マウスがボタンから外れたとき
    public void OnPointerExit(PointerEventData eventData)
    {
        itemExplain.SetActive(false);
        Debug.Log("マウスがボタンから離れました");
    }
}

using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class LoadingAnimPlayer : MonoBehaviour
{
    public float duration = 1f;

    void Start()
    {
        Image[] circles = GetComponentsInChildren<Image>();
        for (int i = 0; i < circles.Length; i++)
        {
            RectTransform rectTransform = circles[i].rectTransform;

            if (rectTransform != null) // nullチェック
            {
                rectTransform.anchoredPosition = new Vector2((i - circles.Length / 2) * 50f, 0);
                Sequence sequence = DOTween.Sequence()
                    .SetLoops(-1, LoopType.Restart)
                    .SetDelay((duration / 2) * ((float)i / circles.Length))
                    .Append(rectTransform.DOAnchorPosY(30f, duration / 4))
                    .Append(rectTransform.DOAnchorPosY(0f, duration / 4))
                    .AppendInterval((duration / 2) * ((float)(1 - i) / circles.Length));
                sequence.Play();
            }
            else
            {
                Debug.LogWarning("RectTransform is null, skipping animation for circle " + i);
            }
        }
    }
}

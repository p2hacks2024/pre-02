using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;//「UniTask」を使用するため。

public class EndSceneView : ViewBase
{
    // トークウインドウ.
    [SerializeField] TalkWindow talkWindow = null;
    // スプレッドシートリーダー.
    [SerializeField] SpreadSheetReader spreadSheetReader = null;
    [SerializeField] bool save_flag = false;

    void Start()
    {
    }

    // -------------------------------------------------------
    // ビューオープン時コール.
    // -------------------------------------------------------
    public override async void OnViewOpened()
    {
        base.OnViewOpened();

        try
        {
            string _sheetId = "1KPZq4XB1bf2zTbpWQt_AWK1p6ghZWFBc1vRuQsq3-Io";
            string _endStory001 = "ノーマルエンド";
            string _endStory002 = "神龍エンド";
            string _endStory003 = "父復活エンド";


            int endnumber = 2;

            Debug.Log("次の展開は" + endnumber);

            switch (endnumber)
            {
                case 0:
                    {
                        var data2_1 = await spreadSheetReader.LoadSpreadSheet(_sheetId, _endStory001);
                        await talkWindow.SetBg(data2_1[0].Place, true);
                        await talkWindow.Open();
                        await talkWindow.TalkStart(data2_1);
                        await talkWindow.Close();//会話終了
                        await Scene.ChangeScene("EndRoll");

                    }
                    break;

                case 1:
                    {
                        var data2_2 = await spreadSheetReader.LoadSpreadSheet(_sheetId, _endStory002);
                        await talkWindow.SetBg(data2_2[0].Place, true);
                        await talkWindow.Open();
                        await talkWindow.TalkStart(data2_2);
                        await talkWindow.Close();//会話終
                        await Scene.ChangeScene("EndRoll");
                    }
                    break;
                case 2:
                    {
                        var data2_3 = await spreadSheetReader.LoadSpreadSheet(_sheetId, _endStory003);
                        await talkWindow.SetBg(data2_3[0].Place, true);
                        await talkWindow.Open();
                        await talkWindow.TalkStart(data2_3);
                        await talkWindow.Close();//会話終
                        await Scene.ChangeScene("EndRoll");
                    }
                    break;
            }
        }
        catch (System.OperationCanceledException e)
        {
            Debug.Log("テスト会話がキャンセルされました。" + e);
        }
    }

    // -------------------------------------------------------
    // ビュークローズ時コール.
    // -------------------------------------------------------
    public override void OnViewClosed()
    {
        base.OnViewClosed();
    }

    // -------------------------------------------------------
    // ホームに戻る.
    // -------------------------------------------------------
    public void OnBackToHomeButtonClicked()
    {
        Scene.ChangeScene("01_Home").Forget();
    }

    // ------------------------------------------------
    /// 2秒待って次のViewに移動.
    // ------------------------------------------------
    async UniTask ChangeViewWaitForSeconds(float waitTime = 2f)
    {
        try
        {
            await UniTask.Delay((int)(waitTime * 1000f), false, PlayerLoopTiming.Update, this.GetCancellationTokenOnDestroy());
            Scene.ChangeView(1).Forget();
            //(非同期処理).Forget() : 非同期処理を待機せずに実行.
        }
        catch (System.OperationCanceledException e)
        {
            Debug.Log("ChangeViewWaitForSecondsがキャンセルされました。" + e);
        }
    }
}

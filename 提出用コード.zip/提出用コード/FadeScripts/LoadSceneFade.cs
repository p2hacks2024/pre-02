using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadSceneFade : MonoBehaviour
{
    [SerializeField] private Fade fade;
    public float outFadeTime = 2.0f;
    public float inFadeTime = 2.0f;
    private bool isFadeOutComplete = false;
    private float time = 0f;
    public float waitTime = 3f;

    // Start is called before the first frame update
    void Start()
    {
        // フェードアウトを開始
        fade.FadeOut(outFadeTime, () => isFadeOutComplete = true);
    }

    // Update is called once per frame
    void Update()
    {
        if (isFadeOutComplete)
        {
            // フェードアウト完了後の待機時間を加算
            time += Time.deltaTime;

            if (time > waitTime)
            {
                // フェードインを開始
                fade.FadeIn(inFadeTime, () =>
                {
                    Debug.Log(SceneManeger.beforeScene);
                    Debug.Log(FloorCaunt.nowfloorcaunt);
                    if (SceneManeger.beforeScene == "ShopScene" || SceneManeger.beforeScene == "IventScene")
                    {
                        SceneManager.LoadScene("PlayScene");//ゲームシーンに切り替える処理
                        Debug.Log("ゲームに移動");
                    }
                    else if (SceneManeger.beforeScene == "PlayScene" && FloorCaunt.nowfloorcaunt < 5)
                    {
                        SceneManager.LoadScene("IventScene");//イベントシーンに切り替える処理
                        Debug.Log("イベントに移動");
                    }
                    else if (SceneManeger.beforeScene == "StoryScene1")
                    {
                        SceneManager.LoadScene("ShopScene");//ショップシーンに切り替える処理
                        Debug.Log("ショップに移動");
                    }
                    else if (SceneManeger.beforeScene == "PlayScene" && FloorCaunt.nowfloorcaunt == 5)
                    {
                        SceneManager.LoadScene("EndStoryScene");//エンドストーリシーンに切り替える処理
                        Debug.Log("エンドストーリに移動");
                    }
                });

                // 待機処理を停止
                isFadeOutComplete = false;
            }
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoryScene : SceneBase
{
    protected override void Start()
    {
        SceneManeger.beforeScene = "StoryScene1";
        base.Start();
    }
}

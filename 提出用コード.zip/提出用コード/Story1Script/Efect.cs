using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;//「Image」などUnityのGUIを使用するために追加しています。
// using Cysharp.Threading.Tasks;
using TMPro;//「UniTask」を使用するため。

public class Efect : MonoBehaviour
{

    [SerializeField] TextMeshProUGUI text = null;
    [SerializeField] Image image = null;
    [SerializeField] bool _blink = true;
    // 点滅周期[s]
    [SerializeField] float _cycle = 1.0f;
    [SerializeField] float interval = 0.5f;

    private double _time;
    float repeatValue;
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        // 内部時刻を経過させる
        _time += Time.deltaTime;
        // 周期cycleで繰り返す値の取得
        // 0～cycleの範囲の値が得られる
        repeatValue = Mathf.Repeat((float)_time, _cycle);
        Blink(_blink, repeatValue);
    }

    public void Blink(bool b, float repeatValue)
    {
        if (b && text != null)
        {
            text.enabled = repeatValue >= _cycle * interval;
        }
        if (b && image != null)
        {
            image.enabled = repeatValue >= _cycle * interval;
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;//「UniTask」を使用するため。
using TMPro;//「TextMeshPro(テキスト表示)」を使用するため。
using UnityEngine.UI;//「Image」などUnityのGUIを使用するために追加しています。
using UnityEngine.SceneManagement;
using System;//追加

// -----------------------------------------------------------------
// 会話ウインドウ.
// -----------------------------------------------------------------
public class StoryText : MonoBehaviour
{
    // 会話内容.
    //「MultiLine( 3 )」という属性が付いており、これによりInspectorで「Text」が３行の入力欄になります。     
    [Multiline(10)] public string Text = "";
    [SerializeField] float text_speed = 0.2f;
    // 会話のトランジション.
    [SerializeField] UITransition textWindowTransition = null;
    // 会話内容テキスト.
    [SerializeField] TextMeshProUGUI storyText = null;
    // 次ページへ表示画像.
    [SerializeField] TextMeshProUGUI nextArrow = null;
    [SerializeField] public List<StoryData> Texts = new List<StoryData>();

    // 次へフラグ.
    bool goToNextPage = false;
    // 次へ行けるフラグ.
    bool currentPageCompleted = false;
    // スキップフラグ.
    bool isSkip = false;

    void Awake()
    {
        textWindowTransition.gameObject.SetActive(false);
    }

    void Start()
    {
        // テスト用会話開始.(後で消します)
        // await Open();
        // await TextStart( TextS );
        // await Close();
        // Debug.Log( "テスト終了" );
    }

    // -----------------------------------------------------------------
    // ウインドウを開く.
    // -----------------------------------------------------------------
    public async UniTask Open(string initName = "", string initText = "")
    {
        storyText.text = initText;
        nextArrow.gameObject.SetActive(false);
        textWindowTransition.gameObject.SetActive(true);
        await textWindowTransition.TransitionInWait();
    }

    // -----------------------------------------------------------------
    // ウインドウを閉じる.
    // -----------------------------------------------------------------
    public async UniTask Close()
    {
        await textWindowTransition.TransitionOutWait();
        textWindowTransition.gameObject.SetActive(false);
    }

    // 色替え用追加部分. ********
    bool isInTag = false;
    string tagStrings = "";
    // *************************

    // -----------------------------------------------------------------
    // 会話の開始.
    // -----------------------------------------------------------------
    public async UniTask<List<int>> TextStart(List<StoryData> textList, float wordInterval = 0.2f)
    {
        try
        {
            List<int> responseList = new List<int>();

            foreach (var text in textList)
            {
                storyText.text = "";
                goToNextPage = false;
                isSkip = false;
                nextArrow.gameObject.SetActive(false);

                await UniTask.Delay((int)(text_speed * 1000f), cancellationToken: this.gameObject.GetCancellationTokenOnDestroy());//文字送り速度

                foreach (char word in text.Text)
                {
                    // 色替え用追加部分. *****************
                    bool isCloseTag = false;
                    if (word.ToString() == "<")
                    {
                        // Debug.Log( "< です。" );
                        isInTag = true;
                    }
                    else if (word.ToString() == ">")
                    {
                        // Debug.Log( "> です。" );
                        isInTag = false;
                        isCloseTag = true;
                    }


                    if (isInTag == false && isCloseTag == false && string.IsNullOrEmpty(tagStrings) == false)
                    {
                        var _word = tagStrings + word;
                        storyText.text += _word;
                        tagStrings = "";
                    }
                    else if (isInTag == true || isCloseTag == true)
                    {
                        tagStrings += word;
                        // Debug.Log( "Tab内です。" );
                        continue;
                    }
                    else
                    {
                        storyText.text += word;
                    }
                    // ********************************
                    // 下の文字追加処理をコメントアウト.
                    // storyText.text += word;
                    // ********************************
                    await UniTask.Delay((int)(wordInterval * 1000f), cancellationToken: this.gameObject.GetCancellationTokenOnDestroy());

                    if (isSkip == true)
                    {
                        storyText.text = text.Text;
                        break;
                    }
                }


                currentPageCompleted = true;
                nextArrow.gameObject.SetActive(true);
                await UniTask.WaitUntil(() => goToNextPage == true, cancellationToken: this.gameObject.GetCancellationTokenOnDestroy());
                LoadScene();
            }

            return responseList;
        }
        catch (System.OperationCanceledException e)
        {
            Debug.Log("TextStart キャンセル。");
            throw e;
        }
    }

    // -----------------------------------------------------------------
    // 次へボタンクリックコールバック.
    // -----------------------------------------------------------------
    public void OnNextButtonClicked()
    {
        Debug.Log("押されました");
        if (currentPageCompleted == true) goToNextPage = true;
        else isSkip = true;
    }

    public void LoadScene()
    {
        if (isSkip)
        {
            SceneManager.LoadSceneAsync("LoadScene");
        }
    }
}
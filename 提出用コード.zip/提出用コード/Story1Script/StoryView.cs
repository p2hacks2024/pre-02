using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;//「UniTask」を使用するため。

public class StoryView : ViewBase
{
    // トークウインドウ.
    [SerializeField] StoryText storyText = null;
    // スプレッドシートリーダー.
    [SerializeField] SpreadSheetReader spreadSheetReader = null;
    void Start()
    {
    }

    // -------------------------------------------------------
    // ビューオープン時コール.
    // -------------------------------------------------------
    public override async void OnViewOpened()
    {
        base.OnViewOpened();
        try
        {
            string _sheetId = "1KPZq4XB1bf2zTbpWQt_AWK1p6ghZWFBc1vRuQsq3-Io";
            string _sheetName = "StoryData001";

            var data = await spreadSheetReader.LoadSpreadSheet(_sheetId, _sheetName);

            await storyText.Open();
            var response = await storyText.TextStart(data);
            await storyText.Close();
        }
        catch (System.OperationCanceledException e)
        {
            Debug.Log("テキスト出力がキャンセルされました。" + e);
        }
    }

    // -------------------------------------------------------
    // ビュークローズ時コール.
    // -------------------------------------------------------
    public override void OnViewClosed()
    {
        base.OnViewClosed();
    }

    // // -------------------------------------------------------
    // // ホームに戻る.
    // // -------------------------------------------------------
    // public void OnBackToHomeButtonClicked()
    // {
    //     Scene.ChangeScene("01_Home").Forget();
    // }

    // ------------------------------------------------
    /// 2秒待って次のViewに移動.
    // ------------------------------------------------
    async UniTask ChangeViewWaitForSeconds(float waitTime = 2f)
    {
        try
        {
            await UniTask.Delay((int)(waitTime * 1000f), false, PlayerLoopTiming.Update, this.GetCancellationTokenOnDestroy());
            Scene.ChangeView(1).Forget();
            //(非同期処理).Forget() : 非同期処理を待機せずに実行.
        }
        catch (System.OperationCanceledException e)
        {
            Debug.Log("ChangeViewWaitForSecondsがキャンセルされました。" + e);
        }
    }
}
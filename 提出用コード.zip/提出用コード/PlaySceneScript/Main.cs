using System;
using System.Threading;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Main : MonoBehaviour
{
    // タイルの種類
    private enum TileType
    {
        Wall, // 何も無い
        GROUND, // 地面
        TARGET, // 目的地
        PLAYER, // プレイヤー
        BLOCK, // ブロック

        PLAYER_ON_TARGET, // プレイヤー（目的地の上）
        BLOCK_ON_TARGET, // ブロック（目的地の上）
        ICEGROUND, // 氷床
        ICEBLOCK, //　氷ブロック
        STAIR // 階段
    }
    // 方向の種類
    private enum DirectionType
    {
        UP, // 上
        RIGHT, // 右
        DOWN, // 下
        LEFT, // 左
    }

    public TextAsset stageFile; // ステージ構造が記述されたテキストファイル
    public List<TextAsset> stageList = new List<TextAsset>();
    public new GameObject camera;

    public static int rows; // 行数
    public static int columns; // 列数
    private static TileType[,] tileList; // タイル情報を管理する二次元配列

    public float tileSize; // タイルのサイズ

    public Sprite wallBottomSprite; // 壁のスプライト
    public Sprite wallTopSprite; // 壁のスプライト
    public Sprite groundSprite; // 地面のスプライト
    public Sprite targetSprite; // 目的地のスプライト
    public Sprite blockSprite; // ブロックのスプライト
    public Sprite iceGroundSprite; //氷床のスプライト
    public Sprite iceBlockSprite; //氷ブロックのスプライト
    public Sprite stairSprite; //階段のスプライト
    public Sprite startStairSprite; //開始時の階段のスプライト
    private Sprite[] playerImages;

    public static GameObject player; // プレイヤーのゲームオブジェクト
    private Vector2 middleOffset; // 中心位置
    private int blockCount; // ブロックの数

    // 各位置に存在するゲームオブジェクトを管理する連想配列
    public static Dictionary<GameObject, Vector2Int> gameObjectPosTable = new Dictionary<GameObject, Vector2Int>();

    public float cameraX = 0;
    public float cameraY = 0;
    SpriteRenderer mainSpriteRenderer;
    public GameObject light;

    // ゲーム開始時に呼び出される
    private void Start()
    {
        //mainSpriteRenderer = player.GetComponent<SpriteRenderer>();
        playerImages = new Sprite[]
    {
            Resources.Load<Sprite>("B_bless"),
            Resources.Load<Sprite>("B_l"),
            Resources.Load<Sprite>("B_normal"),
            Resources.Load<Sprite>("B_r"),
            Resources.Load<Sprite>("F_bless"),
            Resources.Load<Sprite>("F_l"),
            Resources.Load<Sprite>("F_normal"),
            Resources.Load<Sprite>("F_r"),
            Resources.Load<Sprite>("L_normal"),
            Resources.Load<Sprite>("L_W"),
            Resources.Load<Sprite>("R_normal"),
            Resources.Load<Sprite>("R_W"),
    };

        LoadTileData(); // タイルの情報を読み込む
        CreateStage(); // ステージを作成

    }
    // 毎フレーム呼び出される
    private void Update()
    {
        //カメラの追従
        camera.transform.position = new Vector3(player.transform.position.x + cameraX, player.transform.position.y + cameraY, -10);

        //光源の追従
        light.transform.position = new Vector3(player.transform.position.x + tileSize / 2, player.transform.position.y - tileSize / 2, 0);

        // 上矢印が押された場合
        if (Input.GetKeyDown(KeyCode.W))
        {
            mainSpriteRenderer.sprite = playerImages[2];
            // プレイヤーが上に移動できるか検証
            TryMovePlayer(DirectionType.UP);
        }
        // 右矢印が押された場合
        else if (Input.GetKeyDown(KeyCode.D))
        {
            mainSpriteRenderer.sprite = playerImages[10];            // プレイヤーが右に移動できるか検証
            TryMovePlayer(DirectionType.RIGHT);
        }
        // 下矢印が押された場合
        else if (Input.GetKeyDown(KeyCode.S))
        {
            mainSpriteRenderer.sprite = playerImages[6];            // プレイヤーが下に移動できるか検証
            TryMovePlayer(DirectionType.DOWN);
        }
        // 左矢印が押された場合
        else if (Input.GetKeyDown(KeyCode.A))
        {
            mainSpriteRenderer.sprite = playerImages[8];            // プレイヤーが左に移動できるか検証
            TryMovePlayer(DirectionType.LEFT);
        }

        // 階段にたどり着いた時クリアする
        if (TileCheck(gameObjectPosTable[player]) == TileType.STAIR)
        {
            Thread.Sleep(1000);
            FloorCaunt.nowfloorcaunt++;
            SceneManeger.beforeScene = "PlayScene";
            SceneManager.LoadScene("LoadScene");//シーンを切り替える処理
        }
    }
    // タイルの情報を読み込む
    private void LoadTileData()
    {
        stageFile = stageList[0];
        // タイルの情報を一行ごとに分割
        var lines = stageFile.text.Split
        (
            new[] { '\r', '\n' },
            System.StringSplitOptions.RemoveEmptyEntries
        );

        // タイルの列数を計算
        var nums = lines[0].Split(new[] { ',' });

        // タイルの列数と行数を保持
        rows = lines.Length; // 行数
        columns = nums.Length; // 列数

        // タイル情報を int 型の２次元配列で保持
        tileList = new TileType[columns, rows];
        for (int y = 0; y < rows; y++)
        {
            // 一文字ずつ取得
            var st = lines[y];
            nums = st.Split(new[] { ',' });
            for (int x = 0; x < columns; x++)
            {
                // 読み込んだ文字を数値に変換して保持
                tileList[x, y] = (TileType)int.Parse(nums[x]);
            }
        }
    }

    // ステージを作成
    private void CreateStage()
    {
        // ステージの中心位置を計算
        middleOffset.x = columns * tileSize * 0.5f - tileSize * 0.5f;
        middleOffset.y = rows * tileSize * 0.5f - tileSize * 0.5f;
        for (int y = 0; y < rows; y++)
        {
            for (int x = 0; x < columns; x++)
            {
                var val = tileList[x, y];

                // タイルの名前に行番号と列番号を付与
                var name = "tile" + y + "_" + x;

                // タイルのゲームオブジェクトを作成
                var tile = new GameObject(name);

                // タイルにスプライトを描画する機能を追加
                var sr = tile.AddComponent<SpriteRenderer>();

                // タイルのスプライトを設定
                sr.sprite = groundSprite;

                // 目的地の描画順を手前にする
                sr.sortingOrder = 0;

                // タイルの位置を設定
                tile.transform.position = GetDisplayPosition(x, y + 0.25f);

                // 目的地の場合
                if (val == TileType.TARGET)
                {
                    // 目的地のゲームオブジェクトを作成
                    var destination = new GameObject("destination");

                    // 目的地にスプライトを描画する機能を追加
                    sr = destination.AddComponent<SpriteRenderer>();

                    // 目的地のスプライトを設定
                    sr.sprite = targetSprite;

                    // 目的地の描画順を手前にする
                    //sr.sortingOrder = 1;

                    // 目的地の位置を設定
                    destination.transform.position = GetDisplayPosition(x, y);
                }
                // プレイヤーの場合
                if (val == TileType.PLAYER)
                {
                    // プレイヤーのゲームオブジェクトを作成
                    player = new GameObject("player");

                    // プレイヤーにスプライトを描画する機能を追加
                    mainSpriteRenderer = player.AddComponent<SpriteRenderer>();

                    // プレイヤーのスプライトを設定
                    mainSpriteRenderer.sprite = playerImages[6];

                    // プレイヤーの描画順を手前にする
                    mainSpriteRenderer.sortingOrder = 2;

                    // プレイヤーの位置を設定
                    player.transform.position = GetDisplayPosition(x, y);

                    // プレイヤーを連想配列に追加
                    gameObjectPosTable.Add(player, new Vector2Int(x, y));


                    // 開始時の階段のゲームオブジェクトを作成
                    var StartStair = new GameObject("startStair");

                    // 開始時の階段にスプライトを描画する機能を追加
                    sr = StartStair.AddComponent<SpriteRenderer>();

                    // 開始時の階段のスプライトを設定
                    sr.sprite = startStairSprite;

                    // 開始時の階段の描画順を手前にする
                    sr.sortingOrder = 1;

                    // 開始時の階段の位置を設定
                    StartStair.transform.position = GetDisplayPosition(x, y);

                    // 開始時の階段を連想配列に追加
                    gameObjectPosTable.Add(StartStair, new Vector2Int(x, y));
                }
                // ブロックの場合
                else if (val == TileType.BLOCK)
                {
                    // ブロックの数を増やす
                    blockCount++;

                    // ブロックのゲームオブジェクトを作成
                    var block = new GameObject("block" + blockCount);

                    // ブロックにスプライトを描画する機能を追加
                    sr = block.AddComponent<SpriteRenderer>();

                    // ブロックのスプライトを設定
                    sr.sprite = blockSprite;

                    // ブロックの描画順を手前にする
                    sr.sortingOrder = 2;

                    // ブロックの位置を設定
                    block.transform.position = GetDisplayPosition(x, y);

                    // ブロックを連想配列に追加
                    gameObjectPosTable.Add(block, new Vector2Int(x, y));
                }
                // 壁の場合
                if (val == TileType.Wall)
                {
                    // 壁（下）のゲームオブジェクトを作成
                    var wallBottom = new GameObject("wallBottom" + y + "_" + x);

                    // 壁（下）にスプライトを描画する機能を追加
                    sr = wallBottom.AddComponent<SpriteRenderer>();

                    // 壁（下）のスプライトを設定
                    sr.sprite = wallBottomSprite;

                    // 壁（下）の描画順を手前にする
                    sr.sortingOrder = 1;

                    // 壁（下）の位置を設定
                    wallBottom.transform.position = GetDisplayPosition((float)x, (float)(y + 0.25));

                    // 壁（下）を連想配列に追加
                    gameObjectPosTable.Add(wallBottom, new Vector2Int(x, y));

                    // 壁（下）にWallContinueを付与
                    wallBottom.AddComponent<WallContinue>();


                    // 壁（上）のゲームオブジェクトを作成
                    var wallTop = new GameObject("wallTop" + y + "_" + x);

                    // 壁（上）にスプライトを描画する機能を追加
                    sr = wallTop.AddComponent<SpriteRenderer>();

                    // 壁（上）のスプライトを設定
                    sr.sprite = wallTopSprite;

                    // 壁（上）の描画順を手前にする
                    sr.sortingOrder = 3;

                    // 壁（上）の位置を設定
                    wallTop.transform.position = GetDisplayPosition((float)x, (float)(y + 0.25));
                }
                else if (val == TileType.ICEGROUND)
                {
                    // 氷床のゲームオブジェクトを作成
                    var IceGround = new GameObject("iceGround");

                    // 氷床にスプライトを描画する機能を追加
                    sr = IceGround.AddComponent<SpriteRenderer>();

                    // 氷床のスプライトを設定
                    sr.sprite = iceGroundSprite;

                    // 氷床の描画順を手前にする
                    sr.sortingOrder = 0;

                    // 氷床の位置を設定
                    IceGround.transform.position = GetDisplayPosition(x, y);

                    // 氷床を連想配列に追加
                    gameObjectPosTable.Add(IceGround, new Vector2Int(x, y));
                }
                else if (val == TileType.ICEBLOCK)
                {
                    // 氷ブロックのゲームオブジェクトを作成
                    var IceBlock = new GameObject("iceBlock");

                    // 氷ブロックにスプライトを描画する機能を追加
                    sr = IceBlock.AddComponent<SpriteRenderer>();

                    // 氷ブロックのスプライトを設定
                    sr.sprite = iceBlockSprite;

                    // 氷ブロックの描画順を手前にする
                    sr.sortingOrder = 0;

                    // 氷ブロックの位置を設定
                    IceBlock.transform.position = GetDisplayPosition(x, y);

                    // 氷ブロックを連想配列に追加
                    gameObjectPosTable.Add(IceBlock, new Vector2Int(x, y));
                }
                else if (val == TileType.STAIR)
                {
                    // 階段のゲームオブジェクトを作成
                    var Stair = new GameObject("stair");

                    // 階段にスプライトを描画する機能を追加
                    sr = Stair.AddComponent<SpriteRenderer>();

                    // 階段のスプライトを設定
                    sr.sprite = stairSprite;

                    // 階段の描画順を手前にする
                    sr.sortingOrder = 1;

                    // 階段の位置を設定
                    Stair.transform.position = GetDisplayPosition(x, y);

                    // 階段を連想配列に追加
                    gameObjectPosTable.Add(Stair, new Vector2Int(x, y));
                }
            }
        }
    }

    // 指定された行番号と列番号からスプライトの表示位置を計算して返す
    private Vector2 GetDisplayPosition(float x, float y)
    {
        return new Vector2
        (
            x * tileSize - middleOffset.x,
            y * -tileSize + middleOffset.y
        );
    }

    // 指定された位置に存在するゲームオブジェクトを返します
    private GameObject GetGameObjectAtPosition(Vector2Int pos)
    {
        foreach (var pair in gameObjectPosTable)
        {
            // 指定された位置が見つかった場合
            if (pair.Value == pos)
            {
                // その位置に存在するゲームオブジェクトを返す
                return pair.Key;
            }
        }
        return null;
    }

    // 指定された位置がステージ内なら true を返す
    private bool IsValidPosition(Vector2Int pos)
    {
        if (0 <= pos.x && pos.x < columns && 0 <= pos.y && pos.y < rows)
        {
            return tileList[pos.x, pos.y] != TileType.Wall;
        }
        return false;
    }

    //  指定された位置のタイルの種類を返す
    private static TileType TileCheck(Vector2Int pos)
    {
        var cell = tileList[pos.x, pos.y];
        return (TileType)cell;
    }

    // 指定された方向にプレイヤーが移動できるか検証
    // 移動できる場合は移動する
    private void TryMovePlayer(DirectionType direction)
    {
        // プレイヤーの現在地を取得
        var currentPlayerPos = gameObjectPosTable[player];

        // プレイヤーの移動先の位置を計算
        var nextPlayerPos = GetNextPositionAlong(currentPlayerPos, direction);

        // プレイヤーの移動先がステージ内ではない場合は無視
        if (!IsValidPosition(nextPlayerPos)) return;

        // プレイヤーの移動先にブロックが存在する場合
        if (TileCheck(nextPlayerPos) == TileType.BLOCK)
        {
            // ブロックの移動先の位置を計算
            var nextBlockPos = GetNextPositionAlong(nextPlayerPos, direction);

            // ブロックの移動先がステージ内の場合かつ
            // ブロックの移動先にブロックが存在しない場合
            if (IsValidPosition(nextBlockPos) && TileCheck(nextBlockPos) != TileType.BLOCK && TileCheck(nextBlockPos) != TileType.STAIR)
            {
                // 移動するブロックを取得
                var block = GetGameObjectAtPosition(nextPlayerPos);

                // プレイヤーの移動先のタイルの情報を更新
                UpdateGameObjectPosition(nextPlayerPos);


                // プレイヤーの現在地のタイルの情報を更新
                UpdateGameObjectPosition(currentPlayerPos);

                // ブロックを移動
                block.transform.position = GetDisplayPosition(nextBlockPos.x, nextBlockPos.y);

                // プレイヤーを移動
                player.transform.position = GetDisplayPosition(nextPlayerPos.x, nextPlayerPos.y);

                // ブロックの位置を更新
                gameObjectPosTable[block] = nextBlockPos;

                // プレイヤーの位置を更新
                gameObjectPosTable[player] = nextPlayerPos;

                // ブロックの移動先の番号を更新
                if (tileList[nextBlockPos.x, nextBlockPos.y] == TileType.GROUND)
                {
                    // 移動先が地面ならブロックの番号に更新
                    tileList[nextBlockPos.x, nextBlockPos.y] = TileType.BLOCK;
                }
                else if (tileList[nextBlockPos.x, nextBlockPos.y] == TileType.TARGET)
                {
                    // 移動先が目的地ならブロック（目的地の上）の番号に更新
                    tileList[nextBlockPos.x, nextBlockPos.y] = TileType.BLOCK_ON_TARGET;
                }

                // プレイヤーの移動先の番号を更新
                if (tileList[nextPlayerPos.x, nextPlayerPos.y] == TileType.GROUND)
                {
                    // 移動先が地面ならプレイヤーの番号に更新
                    tileList[nextPlayerPos.x, nextPlayerPos.y] = TileType.PLAYER;
                }
                else if (tileList[nextPlayerPos.x, nextPlayerPos.y] == TileType.TARGET)
                {
                    // 移動先が目的地ならプレイヤー（目的地の上）の番号に更新
                    tileList[nextPlayerPos.x, nextPlayerPos.y] = TileType.PLAYER_ON_TARGET;
                }
            }
        }
        // プレイヤーの移動先が氷床の場合
        else if (TileCheck(nextPlayerPos) == TileType.ICEGROUND)
        {
            // プレイヤーの現在地のタイルの情報を更新
            UpdateGameObjectPosition(currentPlayerPos);

            // プレイヤーを移動
            player.transform.position = GetDisplayPosition(nextPlayerPos.x, nextPlayerPos.y);

            // プレイヤーの位置を更新
            gameObjectPosTable[player] = nextPlayerPos;

            // プレイヤーの移動先の番号を更新
            if (tileList[nextPlayerPos.x, nextPlayerPos.y] == TileType.GROUND)
            {
                // 移動先が地面ならプレイヤーの番号に更新
                tileList[nextPlayerPos.x, nextPlayerPos.y] = TileType.PLAYER;
            }
            else if (tileList[nextPlayerPos.x, nextPlayerPos.y] == TileType.TARGET)
            {
                // 移動先が目的地ならプレイヤー（目的地の上）の番号に更新
                tileList[nextPlayerPos.x, nextPlayerPos.y] = TileType.PLAYER_ON_TARGET;
            }
            TryMovePlayer(direction);
        }
        else if (TileCheck(nextPlayerPos) == TileType.ICEBLOCK)
        {
            return;
        }
        // プレイヤーの移動先にブロックが存在しない場合
        else
        {
            // プレイヤーの現在地のタイルの情報を更新
            UpdateGameObjectPosition(currentPlayerPos);

            // プレイヤーを移動
            player.transform.position = GetDisplayPosition(nextPlayerPos.x, nextPlayerPos.y);

            // プレイヤーの位置を更新
            gameObjectPosTable[player] = nextPlayerPos;

            // プレイヤーの移動先の番号を更新
            if (tileList[nextPlayerPos.x, nextPlayerPos.y] == TileType.GROUND)
            {
                // 移動先が地面ならプレイヤーの番号に更新
                tileList[nextPlayerPos.x, nextPlayerPos.y] = TileType.PLAYER;
            }
            else if (tileList[nextPlayerPos.x, nextPlayerPos.y] == TileType.TARGET)
            {
                // 移動先が目的地ならプレイヤー（目的地の上）の番号に更新
                tileList[nextPlayerPos.x, nextPlayerPos.y] = TileType.PLAYER_ON_TARGET;
            }
        }
        // ゲームをクリアしたかどうか確認
        CheckCompletion();
    }

    // 指定された方向の位置を返す
    private Vector2Int GetNextPositionAlong(Vector2Int pos, DirectionType direction)
    {
        switch (direction)
        {
            // 上
            case DirectionType.UP:
                pos.y -= 1;
                break;

            // 右
            case DirectionType.RIGHT:
                pos.x += 1;
                break;

            // 下
            case DirectionType.DOWN:
                pos.y += 1;
                break;

            // 左
            case DirectionType.LEFT:
                pos.x -= 1;
                break;
        }
        return pos;
    }

    // 指定された位置のタイルを更新
    private void UpdateGameObjectPosition(Vector2Int pos)
    {
        // 指定された位置のタイルの番号を取得
        var cell = tileList[pos.x, pos.y];

        // プレイヤーもしくはブロックの場合
        if (cell == TileType.PLAYER || cell == TileType.BLOCK)
        {
            // 地面に変更
            tileList[pos.x, pos.y] = TileType.GROUND;
        }
        // 目的地に乗っているプレイヤーもしくはブロックの場合
        else if (cell == TileType.PLAYER_ON_TARGET || cell == TileType.BLOCK_ON_TARGET)
        {
            // 目的地に変更
            tileList[pos.x, pos.y] = TileType.TARGET;
        }
    }

    // フロアをクリアしたかどうか確認
    // private bool CheckFloorClear()
    // {
    //     TileCheck(player);
    // }

    // ゲームをクリアしたかどうか確認
    private void CheckCompletion()
    {
        // 目的地に乗っているブロックの数を計算
        int blockOnTargetCount = 0;

        for (int y = 0; y < rows; y++)
        {
            for (int x = 0; x < columns; x++)
            {
                if (tileList[x, y] == TileType.BLOCK_ON_TARGET)
                {
                    blockOnTargetCount++;
                }
            }
        }

        // すべてのブロックが目的地の上に乗っている場合
        if (blockOnTargetCount == blockCount)
        {

        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AllMap : MonoBehaviour
{
    public GameObject black;
    public GameObject playerInMap;
    public GameObject parent;
    private GameObject playerIcon;
    private int centerX;
    private int centerY;
    // Start is called before the first frame update
    void Start()
    {
        centerX = Main.rows / 2;
        centerY = Main.columns / 2;
        var obj = Instantiate(black, new Vector3(0, 0, 4), Quaternion.identity);
        obj.transform.SetParent(parent.transform, false);
        obj.transform.localScale = new Vector3(Main.rows, Main.columns, 1f);
        playerIcon = Instantiate(playerInMap, new Vector3((Main.gameObjectPosTable[Main.player].x - centerX) * 8.5f, (Main.gameObjectPosTable[Main.player].y - centerY) * -8.5f, 5), Quaternion.identity);
        playerIcon.transform.SetParent(parent.transform, false);
    }

    // Update is called once per frame
    void Update()
    {
        playerIcon.transform.localPosition = new Vector3((Main.gameObjectPosTable[Main.player].x - centerX) * 8.5f, (Main.gameObjectPosTable[Main.player].y - centerY) * -8.5f, 5);
    }


}

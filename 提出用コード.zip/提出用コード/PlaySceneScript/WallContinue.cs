using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallContinue : MonoBehaviour
{
    public Sprite wallTopFullSprite;
    private Transform objectTransform;
    // Start is called before the first frame update
    void Start()
    {
        if (gameObject == null)
        {
            Debug.LogWarning("GameObjectが存在しません。処理を中止します。");
            return;
        }

        wallTopFullSprite = Resources.Load<Sprite>("StageImage/wallTop");
        objectTransform = transform;

        // gameObject.nameの処理
        string[] splitName = gameObject.name.Split('m', '_');
        int y = int.Parse(splitName[1]) + 1;
        string compareName = splitName[0] + "m" + y.ToString() + "_" + splitName[2];

        foreach (var kvp in Main.gameObjectPosTable)
        {
            if (kvp.Key != null && kvp.Key.name == compareName) // nullチェックを追加
            {
                var spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
                if (spriteRenderer != null)
                {
                    spriteRenderer.sprite = wallTopFullSprite;
                }
                else
                {
                    Debug.LogWarning("SpriteRendererが見つかりません。");
                }
                break;
            }
        }
    }


    // Update is called once per frame
    void Update()
    {

    }
}

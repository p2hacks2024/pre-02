using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManeger : MonoBehaviour
{
    public static string beforeScene = null;
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("前のシーン：" + beforeScene);
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void LoadSceneClike()
    {
        beforeScene = SceneManager.GetActiveScene().name;
        SceneManager.LoadScene(beforeScene);//シーンを切り替える処理
    }
}

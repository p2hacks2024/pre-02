using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;//追加
using System.Threading;//追加
using UnityEngine.Events;//追加
using Cysharp.Threading.Tasks;//追加

[RequireComponent(typeof(CanvasGroup))]//CanvasGroupもアタッチされる
public class UITransition : MonoBehaviour
{
    // レクトトランスフォーム取得用.
    public RectTransform Rect
    {
        get
        {
            if (rect == null) rect = GetComponent<RectTransform>();
            return rect;
        }
    }
    // レクトトランスフォーム保管用.
    RectTransform rect = null;

    // 設定値.
    [System.Serializable]
    public class TransitionParam
    {
        // 実行フラグ.
        public bool IsActive = true;
        // インの値.
        public Vector2 In = new Vector2(0, 1f);
        // アウトの値.
        public Vector2 Out = new Vector2(1f, 0);
    }

    // フェード設定値.
    [SerializeField] TransitionParam fade = new TransitionParam();
    // スケール設定値.
    [SerializeField] TransitionParam scale = new TransitionParam() { IsActive = false, In = Vector2.zero, Out = Vector2.zero };
    // 遷移時間.
    [SerializeField] float duration = 1f;

    // キャンバスグループ取得用.
    public CanvasGroup Canvas
    {
        get
        {
            if (canvas == null) canvas = GetComponent<CanvasGroup>();
            return canvas;
        }
    }

    //! インのシークエンス.
    Sequence inSequence = null;
    //! アウトのシークエンス.
    Sequence outSequence = null;

    // キャンバスグループ保管用.
    CanvasGroup canvas = null;

    //! インのキャンセルトークン.
    CancellationTokenSource inCancellation = null;
    //! アウトのキャンセルトークン.
    CancellationTokenSource outCancellation = null;

    void Start()
    {
        // 以下処理はテスト用なので削除.
        // await TransitionInWait();
        // Debug.Log( "遷移の終了" );
    }

    // ----------------------------------------------------
    // トランジションイン.
    // ----------------------------------------------------
    public void TransitionIn(UnityAction onCompleted = null)
    {
        if (inSequence != null)
        {
            inSequence.Kill();
            inSequence = null;
        }
        inSequence = DOTween.Sequence();//シークエンスを新しく作る

        if (fade.IsActive == true && Canvas != null)
        {
            Canvas.alpha = fade.In.x;
            inSequence.Join//前の処理と同時に行うための記載
            (
                Canvas.DOFade(fade.In.y, duration).SetLink(gameObject)
            );
            //<DOTween>
            //CanvasGroup.DOFade( 最終値, 遷移時間 ) : キャンバスグループの「Alpha(透明度)」を遷移時間で変化させる       
            //SetLink(OO):DoTweenの処理にリンク（Link）させて、OOがなくなったら中断させる
        }

        if (scale.IsActive == true)
        {
            var current = Rect.transform.localScale;
            Rect.transform.localScale = new Vector3(scale.In.x, scale.In.y, current.z);
            //〇〇.DOScale( 目標値, 遷移時間 ) : スケールを目標値に遷移時間で変化

            inSequence.Join
            (
                Rect.DOScale(current, duration)
                .SetLink(gameObject)
            );
        }

        inSequence
        .SetLink(gameObject)
        .OnComplete(() => onCompleted?.Invoke());
    }

    // ----------------------------------------------------
    // トランジションアウト.
    // ----------------------------------------------------
    public void TransitionOut(UnityAction onCompleted = null)
    {
        if (outSequence != null)
        {
            outSequence.Kill();//シークエンスを中断
            outSequence = null;
        }
        outSequence = DOTween.Sequence();

        if (fade.IsActive == true && Canvas != null)
        {
            Canvas.alpha = fade.Out.x;
            outSequence.Join
            (
                Canvas.DOFade(fade.Out.y, duration).SetLink(gameObject)
            );
            //<DOTween>
            //CanvasGroup.DOFade( 最終値, 遷移時間 ) : キャンバスグループの「Alpha(透明度)」を遷移時間で変化させる       
        }

        if (scale.IsActive == true)
        {
            var current = Rect.transform.localScale;
            outSequence.Join
            (
                Rect.DOScale(new Vector3(scale.Out.x, scale.Out.y, current.z), duration)
                .SetLink(gameObject)
                .OnComplete(() => Rect.transform.localScale = current)
            );
        }

        outSequence
        .SetLink(gameObject)
       .OnComplete(() => onCompleted?.Invoke());
    }

    /// ----------------------------------------------------
    // トランジションイン終了待機.
    // ----------------------------------------------------
    public async UniTask TransitionInWait()
    {
        bool isDone = false;
        if (inCancellation != null)
        {
            inCancellation.Cancel();
        }
        inCancellation = new CancellationTokenSource();

        TransitionIn(() => { isDone = true; });

        try
        {
            await UniTask.WaitUntil(() => isDone == true, PlayerLoopTiming.Update, inCancellation.Token);
        }
        catch (System.OperationCanceledException e)
        {
            Debug.Log("キャンセルされました。" + e);
            throw e;
        }
    }

    // ----------------------------------------------------
    // トランジションアウト終了待機.
    // ----------------------------------------------------
    public async UniTask TransitionOutWait()
    {
        bool isDone = false;
        if (outCancellation != null)
        {
            outCancellation.Cancel();
        }
        outCancellation = new CancellationTokenSource();

        TransitionOut(() => { isDone = true; });

        try
        {
            await UniTask.WaitUntil(() => isDone == true, PlayerLoopTiming.Update, outCancellation.Token);
        }
        catch (System.OperationCanceledException e)
        {
            Debug.Log("キャンセルされました。" + e);
            throw e;
        }
    }

    // ----------------------------------------------------
    // 破棄された時のコールバック.
    // ----------------------------------------------------
    void OnDestroy()
    {
        if (inCancellation != null)
        {
            inCancellation.Cancel();
        }
        if (outCancellation != null)
        {
            outCancellation.Cancel();
        }
    }
}